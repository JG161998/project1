package app;


public class PrintHeader {


    public static void printStepHeader(int stepNumber){

        System.out.println();
        System.out.println("=================================================");
        System.out.println("Step -> " + stepNumber);
        System.out.println("=================================================");
        

    }
}
