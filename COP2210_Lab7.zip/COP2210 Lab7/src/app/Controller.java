package app;

public class Controller {

    //----------------------------------------------------------------------------------------------------
    // beginning of main(String[] args) method

    public static void main(String[] args) {

        yourInfoHeader();

        PrintHeader.printStepHeader(1);

        for (int i = -10; i <= 10; i++) {
            System.out.println("The value of i is: " + i);
        }//end for
        PrintHeader.printStepHeader(2);
        for (int k = 0; k <= 8; k += 2) {
            System.out.println("The value of k is: " + k);
        }//end for
        PrintHeader.printStepHeader(3);
        for (int l = 10; l >= 1; l--) {
            System.out.println("The value of l is: " + l);
        }// end for
        PrintHeader.printStepHeader(4);
        for (int i = 0; i <= 20; i++) {
            System.out.print("The value of i is: " + i + "\t\t");
            if (i % 2 == 0) {
                System.out.println("even");
            } else {
                System.out.println("odd");
            }// end for
        }

        PrintHeader.printStepHeader(5);
        for (int i = 0; i <= 20; i++) {
            if (i < 10) {
                if (i % 2 == 0) {
                    System.out.println("the value of i is: " + i + "\t\teven");
                } else {
                    System.out.println("The value of i is: " + i + "\t\todd");
                }
            } else {
                if (i % 2 == 0) {
                    System.out.println("The value of i is: " + i + "\teven");
                } else {
                    System.out.println("The value of i is: " + i + "\todd");
                }
            }
        }

        PrintHeader.printStepHeader(6);
        for (int row = 1; row <= 10; row++) {
            for (int col = 1; col <= 15; col++) {
                System.out.print("x\t");
            }
            System.out.println();
        }

        PrintHeader.printStepHeader(7);
        for (int row = 1; row <= 10; row++) {
            for (int col = 1; col <= 10; col++) {

                if (col % 2 == 1 && row % 2 == 1) {
                    System.out.print("x\t");
                } else {
                    System.out.print("O\t");
                }

            }
            System.out.println();
        }

        PrintHeader.printStepHeader(8);
        for (int row = 1; row <= 10; row++) {
            for (int col = 1; col <= 10; col++) {

                if (row == col) {
                    System.out.print("x\t");
                } else {
                    System.out.print("O\t");
                }
            }
            System.out.println();
        }
        PrintHeader.printStepHeader(9);
        for (int row = 1; row <= 10; row++) {
            for (int col = 1; col <= 10; col++) {
                if (row == col ) {
                    System.out.print("x\t");
                } else {
                    System.out.print("O\t");
                } if (col == 11- row) {
                    System.out.print("x\t");

                }

            }
            System.out.println();
        }
        PrintHeader.printStepHeader(10);
        for(int row = 1; row <=10; row++) {
            for (int col = 1; col <= 10; col++) {
                if (col > 5 && row > 2 && row < 9 ) {
                    System.out.print("x\t");
                } else {
                    System.out.print("O\t");
                }
            }

            System.out.println();
        }
        PrintHeader.printStepHeader(11);
        for(int row = 1; row <= 10; row++){
            for(int col = 1; col <= 10; col++){

                if (col % 2 == 1 && row % 2 == 1 || col % 6 == 3 || row % 2 == 1 ){
                    System.out.print("x\t");
                } else {
                    System.out.print("O\t");
                }
            }
        System.out.println();
        }


    }






    //----------------------------------------------------------------------------------------------
    // beginning of yourInfoHeader() method

    public static void yourInfoHeader(){

        System.out.println("=============================================");
        System.out.println("PROGRAMMER: " + "Joshua Gomez");
        System.out.println("PANTHER ID: " + "6082979");
        System.out.println();
        System.out.println("CLASS: \t\t COP2210");
        System.out.println("SECTION: \t " + "U02");
        System.out.println("CLASSTIME: \t" + "Tuesday/Thursday 5:00PM-7:45PM");
        System.out.println();
        System.out.println("ASSIGNMENT: " + "Lab7");
        System.out.println();
        System.out.println("CERTIFICATION: \nI understand FIU's academic policies, and I certify");
        System.out.println("that this work is my own and that none of it is the");
        System.out.println("work of any other program");
        System.out.println("===============================================");
        System.out.println();

    }//end YourInfoHeader




}
